"""
RAG Engine — Core Logic (Modern LangChain LCEL API)
Every architectural decision is an interview talking point.
"""

import os
from pathlib import Path
from typing import List, Tuple, Dict, Any

from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser


def _format_docs(docs) -> str:
    return "\n\n---\n\n".join(doc.page_content for doc in docs)


class RAGEngine:
    """
    Full RAG pipeline using modern LangChain LCEL.

    Phase 1: ingest_documents() — load → chunk → embed → ChromaDB
    Phase 2: query()            — embed → retrieve → LLM → answer + sources
    """

    def __init__(self, api_key, model="gpt-4o-mini", chunk_size=500,
                 chunk_overlap=50, top_k=3, persist_directory="./chroma_db"):
        os.environ["OPENAI_API_KEY"] = api_key
        self.model_name = model
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.top_k = top_k
        self.persist_directory = persist_directory

        # INTERVIEW: Same embedding model for ingestion AND querying — critical!
        # text-embedding-ada-002 = 1536-dimensional semantic vectors
        self.embeddings = OpenAIEmbeddings(model="text-embedding-ada-002", openai_api_key=api_key)

        # INTERVIEW: temperature=0 → deterministic, factual output (no creative drift)
        self.llm = ChatOpenAI(model=model, temperature=0, openai_api_key=api_key)

        # INTERVIEW: RecursiveCharacterTextSplitter tries: \n\n → \n → ". " → " "
        # Preserves semantic coherence vs arbitrary character splits
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size, chunk_overlap=chunk_overlap,
            length_function=len, separators=["\n\n", "\n", ". ", " ", ""]
        )

        self.vectorstore = None
        self.retriever = None
        self._chat_history = []

    def ingest_documents(self, file_paths: List[Tuple[str, str]]) -> Dict[str, int]:
        """Phase 1: Load → Chunk → Embed → Store"""
        all_docs = []
        for temp_path, orig_name in file_paths:
            suffix = Path(temp_path).suffix.lower()
            if suffix == ".pdf":
                loader = PyPDFLoader(temp_path)
            elif suffix in [".txt", ".md"]:
                loader = TextLoader(temp_path, encoding="utf-8")
            else:
                continue
            docs = loader.load()
            for d in docs:
                d.metadata["source_file"] = orig_name
            all_docs.extend(docs)

        if not all_docs:
            raise ValueError("No supported documents found (PDF, TXT, MD).")

        # INTERVIEW: chunk_overlap prevents losing info at chunk boundaries
        chunks = self.text_splitter.split_documents(all_docs)

        # INTERVIEW: ChromaDB stores (text, embedding vector, metadata) per chunk
        # Uses cosine similarity to find relevant chunks at query time
        self.vectorstore = Chroma.from_documents(
            documents=chunks, embedding=self.embeddings,
            persist_directory=self.persist_directory
        )

        # INTERVIEW: MMR (Maximal Marginal Relevance) — retrieves diverse, relevant chunks
        # fetch_k=9 candidates → selects k=3 that maximize relevance AND diversity
        self.retriever = self.vectorstore.as_retriever(
            search_type="mmr",
            search_kwargs={"k": self.top_k, "fetch_k": self.top_k * 3}
        )
        self._chat_history = []
        return {"total_docs": len(file_paths), "total_chunks": len(chunks)}

    def query(self, question: str, chat_history=None) -> Dict[str, Any]:
        """Phase 2: Embed → Retrieve → Generate"""
        if not self.vectorstore:
            raise ValueError("No documents indexed. Call ingest_documents() first.")

        # Retrieve relevant chunks via MMR
        retrieved_docs = self.retriever.invoke(question)
        context = _format_docs(retrieved_docs)

        # INTERVIEW: Prompt engineering — "ONLY use provided context" prevents hallucination
        # Without this constraint, LLM may answer from training data, bypassing documents
        messages = [
            ("system", """You are a precise document assistant. Answer ONLY from the context below.
If insufficient info, say: "I don't have enough information in the provided documents."
Be concise and cite specific document sections when relevant.

Context:
{context}""")
        ]

        # INTERVIEW: Manual conversation memory — injects last 3 exchanges
        # Enables follow-up questions ("what about the second point?")
        for turn in self._chat_history[-6:]:
            messages.append((turn["role"], turn["content"]))
        messages.append(("human", "{question}"))

        prompt = ChatPromptTemplate.from_messages(messages)

        # INTERVIEW: LCEL pipe operator chains: prompt → LLM → string parser
        chain = prompt | self.llm | StrOutputParser()
        answer = chain.invoke({"context": context, "question": question})

        # Update memory
        self._chat_history.append({"role": "human", "content": question})
        self._chat_history.append({"role": "assistant", "content": answer})

        # Format sources with relevance scores
        try:
            scored = self.vectorstore.similarity_search_with_relevance_scores(question, k=self.top_k)
            score_map = {d.page_content[:80]: s for d, s in scored}
        except Exception:
            score_map = {}

        sources, seen = [], set()
        for doc in retrieved_docs:
            t = doc.page_content.strip()
            if t in seen:
                continue
            seen.add(t)
            sources.append({
                "text": t[:600] + ("..." if len(t) > 600 else ""),
                "source": doc.metadata.get("source_file", doc.metadata.get("source", "unknown")),
                "page": doc.metadata.get("page"),
                "score": score_map.get(t[:80], 0.0)
            })

        return {"answer": answer, "sources": sources}

    def clear_history(self):
        self._chat_history = []

    def get_info(self) -> Dict[str, Any]:
        if not self.vectorstore:
            return {"status": "empty"}
        try:
            count = self.vectorstore._collection.count()
        except Exception:
            count = "unknown"
        return {
            "status": "loaded", "total_vectors": count,
            "embedding_model": "text-embedding-ada-002",
            "embedding_dimensions": 1536, "similarity_metric": "cosine",
            "retrieval": "MMR", "chunk_size": self.chunk_size,
            "chunk_overlap": self.chunk_overlap, "top_k": self.top_k
        }
